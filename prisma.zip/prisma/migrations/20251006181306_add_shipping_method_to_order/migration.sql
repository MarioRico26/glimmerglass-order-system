-- AlterTable
ALTER TABLE "public"."Order" ADD COLUMN     "shippingMethod" TEXT;
