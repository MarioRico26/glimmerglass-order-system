-- AlterTable
ALTER TABLE "InventoryReorderLine" ADD COLUMN     "onHand" INTEGER NOT NULL DEFAULT 0;
