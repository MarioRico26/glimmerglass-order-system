-- AlterTable
ALTER TABLE "public"."Order" ADD COLUMN     "factoryLocationId" TEXT;
